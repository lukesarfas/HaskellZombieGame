module Types where

import System.Random (StdGen)




data World = World
  { player :: Player
  , worldBoundaries :: Boundaries
  , gameState :: GameState
  , worldRandomGenerator :: StdGen
  , entities :: [Entity]
  , worldStats :: Stats
  }





data GameState = Title | Playing | GameOver
    deriving (Show, Eq)


data Entity = Entity 
  { entityType      :: EntityType
  , entityHealth    :: EntityHealth
  , entitySize      :: Float
  , entityLocation  :: Location
  }

data EntityType = 
    Enemy 
    | 
    Bullet 
        {startLocation  :: Location} 
    | SupplyPackage
        {packageType    :: PackageType}


    deriving (Show, Eq)


data PackageType = Health 
    deriving (Show, Eq)



data Stats = Stats 
  { level :: Int
  }