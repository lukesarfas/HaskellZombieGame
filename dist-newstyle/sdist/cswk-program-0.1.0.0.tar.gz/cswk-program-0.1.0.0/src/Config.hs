module Config where



gameSize :: (Int, Int)
gameSize = (800,800)

gamePosition :: (Int, Int)
gamePosition = ((1920-gameWidth) `div` 2, (1080-gameHeight) `div` 2)

gameWidth  = fst gameSize
gameHeight = snd gameSize