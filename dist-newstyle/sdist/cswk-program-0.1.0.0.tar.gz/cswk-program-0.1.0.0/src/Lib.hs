module Lib
    ( someFunc
    ) where

{- NOTE that you are NOT obligated to keep any of the files from 
the skeleton code, including this one. You should give your 
modules sensible names that correspond to their contents. -}

someFunc :: IO ()
someFunc = putStrLn "someFunc"
