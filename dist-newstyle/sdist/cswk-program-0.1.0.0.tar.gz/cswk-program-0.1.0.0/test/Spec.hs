
{-
There are no tests provided by default. If you wish
to write some tests as part of your program, then
you can use the Tasty library---see some of the
lab sheets for how that can be done.
-}

main :: IO ()
main = putStrLn "Test suite not yet implemented"
