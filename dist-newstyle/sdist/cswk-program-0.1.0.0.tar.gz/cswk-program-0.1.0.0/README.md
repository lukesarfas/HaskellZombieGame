# cswk-program

This is the skeleton code for the second coursework in the 2022 iteration of CS141 Functional Programming at the University of Warwick.
